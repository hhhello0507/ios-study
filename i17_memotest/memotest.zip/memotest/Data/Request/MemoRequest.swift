struct MemoCreateRequest: Encodable {
    let memo: String
    let createdAt: String
}
