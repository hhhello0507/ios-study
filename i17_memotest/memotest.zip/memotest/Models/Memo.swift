struct Memo {
    var id: String
    var memo: String
    var createdAt: String
}

typealias Memos = [Memo]
