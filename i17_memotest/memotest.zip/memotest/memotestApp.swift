//
//  memotestApp.swift
//  memotest
//
//  Created by dgsw8th71 on 2/4/24.
//

import SwiftUI

@main
struct memotestApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                MemoView()
            }
        }
    }
}
